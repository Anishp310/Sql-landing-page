import PartnersContent from "../components/partners/PartnersContent";
import PartnersCover from "../components/partners/PartnersCover";
import Pricing from "../components/partners/Pricing";

const Partners = () => {
  return (
    <div>
    <Pricing/>
    </div>
  )
}

export default Partners