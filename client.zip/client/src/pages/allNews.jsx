import AllNews from "./../components/home/AllNews";
import MediaCover from "../components/home/MediaCover";

const Media = () => {
  return (
    <div>
    <MediaCover/>
    <AllNews/>
    </div>
  )
}

export default Media