import PricingContent from "../components/Pricing/PricingContent";
import PricingCoverPage from "./../components/Pricing/PricingCoverPage";
import StaticPopularPricingPlan from "../components/Pricing/StaticPopularPricingPlan";

const Pricing = () => {
  return (
    <div>
    <PricingCoverPage/>
    <PricingContent/>
    {/* <StaticPopularPricingPlan/> */}
    </div>
  )
}

export default Pricing;








