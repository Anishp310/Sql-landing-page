import BusinessContent from "../components/business/BusinessContent";
import BusinessCover from "../components/business/BusinessCover";

const Business = () => (
  <div>
    <BusinessCover />
    <BusinessContent />
  </div>
);

export default Business;
