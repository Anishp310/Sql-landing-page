import ContactUsForm from "../components/getInTouch/ContactUsForm";
import GetInTouchCover from "../components/getInTouch/GetInTouchCover";

const GetinTouch = () => {
  return (
    <div>
      <GetInTouchCover/>
    <ContactUsForm/>
     
    
    </div>
  )
}

export default GetinTouch