const Milestones = () => {
  return (
    <div className="xl:mx-[10rem] lg:mx-[3rem] md:mx-[2.5rem] mx-[1rem] ">
      {/* <div className="flex flex-col gap-10 mt-5 md:flex-row">
        <div className="">
          <div className="mb-4 md:mb-2 xl:mb-12 ">
            <h3 className="mb-5 font-semibold md:text-2xl lg::text-3xl text-amber-600">
              Our Mission
            </h3>
            <p className="text-justify text-black md:text-md lg::text-lg text-md">
              Our mission is to develop, produce, and sell software products
              that meet the needs of our customers while creating value for
              them. We aim to provide reliable, effective, and easy-to-use
              software, while fostering positive growth.
            </p>
          </div>
          <div className="mb-12 ">
            <h3 className="mb-5 font-semibold md:text-2xl lg:text-3xl text-amber-600">
              Our Values
            </h3>
            <p className="text-justify text-black md:text-md lg:text-lg text-md">
              We believe in providing excellent customer service and
              continuously improving our products based on customer feedback. We
              uphold integrity and ethics in all operations and value teamwork
              as a key to our success.
            </p>
          </div>
        </div>
        </div> */}
      <div className="my-[10rem]">
        
      </div>
      
    </div>
  )
}

export default Milestones;