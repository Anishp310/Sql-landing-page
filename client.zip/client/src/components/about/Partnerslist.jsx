import PartnersCard from "./PartnersCard";

const Partnerslist = () => {
  return (
    <div>
        <PartnersCard/>
    </div>
  )
}

export default Partnerslist