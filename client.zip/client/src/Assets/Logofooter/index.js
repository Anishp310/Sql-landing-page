import darsanTech from '../Logofooter/darshantech.png'
import diyalo from '../Logofooter/diyalo.png'
import fesewa from '../Logofooter/fesewa.png'
import f1soft from '../Logofooter/f1soft.png'
import fpay from '../Logofooter/fpay.png'
import fpoints from '../Logofooter/fpoints.png'
import logiga from '../Logofooter/logiga.png'
import swastik from '../Logofooter/swastik.png'
import floan from '../Logofooter/floan.png'
import fnext from '../Logofooter/fnext.png'
import edata from '../Logofooter/edata.png'

export{
    darsanTech,
    diyalo,fesewa,f1soft,fpay,fpoints,logiga,swastik,floan,fnext,edata
}