import accounting from './accounting.jpeg'
import ai from './ai.webp'
import coding from './coding.jpeg'
import costefficeinet from './costeff.jpeg'
import inventory from './inventory.jpeg'
import security  from './security1.png'
import report from './reports.jpg'
import calculation from './intcal.jpeg'
import acc366 from './366.webp'
import trading from './tchs.jpeg'
import ui from './ui.webp'
export{
    accounting,ai,security ,coding,costefficeinet,inventory,report,calculation,acc366,trading,ui
}