import Bg_Img from "./bg-img.jpg";
import abanner from "./banner-image.jpg";
import about from "./aboutus.png";
import aboutBanner from "./Aboutbanner.avif";
import admin from "./admin.png";
import checkIcon from "./check.png";
import crossIcon from "./cross.png";
import digijoon from "./digijoon.png";
import joonBanner from "./tech_heading.png";
import joonLogo from "./joonlogo.png";
import joonwork from "./joonwork.png";
import milestone from "./milestone.png";
import mobileBanking from "./mobile-banking.png";
import onlineBanking from "./online-banking.png";
import team from "./mteam.png";
import trader from "./trader.png";
import user from "./users.png";

export {
  joonLogo,
  about,
  admin,
  Bg_Img,
  joonBanner,
  joonwork,
  milestone,
  user,
  aboutBanner,
  abanner,
  digijoon,
  trader,
  onlineBanking,
  mobileBanking,
  team,
  checkIcon,
  crossIcon
};
