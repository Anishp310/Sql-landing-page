import  mvpic from "./mvpicimg.png";
import aboutusimg from "./aboutusimg.png";

export {
    aboutusimg, mvpic
}

